# webtek-innlevering3
Tema: Premier League

Gruppeleder/Nettverksadmin: Patrick Charles Mikael Thor med hammern

Grafisk Designer:  Anders Smørdal

Innhaldsansvarlig: Thomas Drønnesund
